# FaceMaskDetection
The goal is to train a custom deep learning model to detect whether a person is or is not wearing a mask.
This project detects at what percentage the person is wearing mask.
I HAVE DONE THIS PROJECT WITH MY FRIEND YASH SHARMA.
